jQuery(document).ready(function () {
    jQuery('.wpjobportal-color-picker').wpColorPicker();
});

jQuery(document).ajaxComplete(function () {
    jQuery('.wpjobportal-color-picker').wpColorPicker();
});
