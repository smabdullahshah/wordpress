<?php if (!defined('ABSPATH')) die('Restricted Access'); ?>
<?php
/**
* 
*/
?>
<?php
 WPJOBPORTALincluder::getTemplate('highesteducation/views/detail',array(
 	'row' => $row,
 	'i' => $i ,
 	'pagenum' => $pagenum ,
 	'n' => $n ,
 	'pageid' => $pageid ,
 	'islastordershow' => $islastordershow
 ));
?>