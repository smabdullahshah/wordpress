<?php return array('dependencies' => array('wp-components', 'wp-element', 'wp-i18n'), 'version' => 'c02dc915a169cb49bb44');
