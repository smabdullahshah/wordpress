<?php if (!defined('ABSPATH')) die('Restricted Access'); ?>
<?php
/**
* 
*/
?>
<?php
   WPJOBPORTALincluder::getTemplate('state/views/detail',array(
 	'row' => $row,
 	'i' => $i ,
 	'pagenum' => $pagenum ,
 	'n' => $n ,
 	'pageid' => $pageid ,
 	'link' => $link
 	
 ));
?>