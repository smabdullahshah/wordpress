<?php if (!defined('ABSPATH')) die('Restricted Access'); ?>
<?php
/**
* @param recreational Object Loop's

*/
?>
<?php
	$resumelayout = WPJOBPORTALincluder::getObjectClass($layouts);
	$resumelayout->printResume();
?>
