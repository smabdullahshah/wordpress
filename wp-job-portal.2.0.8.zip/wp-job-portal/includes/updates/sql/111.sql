REPLACE INTO `#__wj_portal_config` (`configname`, `configvalue`, `configfor`) VALUES ('versioncode', '1.1.1', 'default');

INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`, `configfor`,`addon`) VALUES ('set_register_redirect_link','1','default','null');
INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`,  `configfor`,`addon`) VALUES ('register_redirect_link','','default','null');
INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`, `configfor`,`addon`) VALUES ('set_login_redirect_link','1','default','null');
INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`,  `configfor`,`addon`) VALUES ('login_redirect_link','','default','null');



