REPLACE INTO `#__wj_portal_config` (`configname`, `configvalue`, `configfor`) VALUES ('versioncode', '1.0.1', 'default');

INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`, `configfor`,`addon`) VALUES ('employe_set_register_link','1','default','null');
INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`,  `configfor`,`addon`) VALUES ('employe_register_link','','default','null');
INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`, `configfor`,`addon`) VALUES ('jobseeker_set_register_link','1','default','null');
INSERT INTO `#__wj_portal_config`(`configname`, `configvalue`,  `configfor`,`addon`) VALUES ('jobseeker_register_link','','default','null');



