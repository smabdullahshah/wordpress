REPLACE INTO `#__wj_portal_config` (`configname`, `configvalue`, `configfor`) VALUES ('versioncode', '2.0.5', 'default');
INSERT INTO `#__wj_portal_config` (`configname`, `configvalue`, `configfor`, `addon`) VALUES ('recaptcha_version',1,'captcha',NULL);
